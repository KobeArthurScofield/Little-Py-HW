# Stock plot
# Kobe Arthur Scofield
# 2018-04-12
# Build 1
# Python: Anaconda3_64 5.0.0.0 (Python 3.6.2)
# IDE: MSVS2017_Community 15.6.6

# Including:
# fileop
"""
File operation.
This file contains functions for file operation.
"""
# stockproc
"""
Containing functions for stock processing.
"""
